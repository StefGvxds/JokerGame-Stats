
package Forms;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import static java.lang.Integer.parseInt;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pkg2022_plh24_omada_6.katigoriaKerdous;
import pkg2022_plh24_omada_6.klirosi;
import pkg2022_plh24_omada_6.opapApi;
import pkg2022_plh24_omada_6.sqlKliroseis;
import java.time.format.DateTimeFormatter;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

public class JokerDataManagementR2 extends javax.swing.JFrame {

    //Αρχικοπίηση της λίστα που κρατάει τις κληρώσεις αναφοράς της φόρμας
    Map<Integer, klirosi> Kliroseis = new HashMap<Integer, klirosi>();
    //Boolean Αν είναι true τότε το πρόγραμμα επιτρέπει την διαγραφή δια συγκεκριμένο εύρος ημερομηνιών 
    boolean DateSettingIsOk;

    //Αρχικοποίηση της φόρμας κατά την εκκίνηση
    public JokerDataManagementR2() {
        initComponents();
        //Το μέγεθος του Παράθυρου Θα έχει σταθερό μέγεθος και δεν θα αλλάζει
        setSize(1030,690);
        //Καθορίζει σε ποιο σημείο της οθόνης θα ανοίξει το παράθυρο 
        setLocationByPlatform(true);
        //Δεν αφήνει στον χρήστη να αλλάξει το μέγεθος του παραθύρου 
        setResizable(false);    
    }
       
    //Κλείνει μόνο ένα συγκεκριμένο παράθυρο και αφήνει τα άλλα ανοιχτά.
    //Λειτουργεί μόνο αν αλλάξουμε στα Properties όλων των JFrames και αλλάξουμε: defaultCloseOperation --> Dispose
    public void close(){
        WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        lblKat = new javax.swing.JLabel();
        lblKatA = new javax.swing.JLabel();
        lblKatB = new javax.swing.JLabel();
        lblKatC = new javax.swing.JLabel();
        lblKatD = new javax.swing.JLabel();
        lblKatE = new javax.swing.JLabel();
        lblKatF = new javax.swing.JLabel();
        lblKatG = new javax.swing.JLabel();
        lblEpit = new javax.swing.JLabel();
        lblEpitA = new javax.swing.JLabel();
        lblEpitB = new javax.swing.JLabel();
        lblEpitC = new javax.swing.JLabel();
        lblEpitD = new javax.swing.JLabel();
        lblEpitE = new javax.swing.JLabel();
        lblEpitF = new javax.swing.JLabel();
        lblEpitG = new javax.swing.JLabel();
        lblKerdiC = new javax.swing.JLabel();
        lblKerdiG = new javax.swing.JLabel();
        lblKerdiD = new javax.swing.JLabel();
        lblKerdi = new javax.swing.JLabel();
        lblKerdiA = new javax.swing.JLabel();
        lblKerdiE = new javax.swing.JLabel();
        lblKerdiB = new javax.swing.JLabel();
        lblKerdiF = new javax.swing.JLabel();
        lblKatH = new javax.swing.JLabel();
        lblEpitH = new javax.swing.JLabel();
        lblKerdiH = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblKlirosi1 = new javax.swing.JLabel();
        lblKlirosi = new javax.swing.JLabel();
        lblNikitria1 = new javax.swing.JLabel();
        lblNikitria = new javax.swing.JLabel();
        lblJoker1 = new javax.swing.JLabel();
        lblJoker = new javax.swing.JLabel();
        lblHmerominia1 = new javax.swing.JLabel();
        lblHmerominia = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        lblMessage = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        btnDeleteOne = new javax.swing.JButton();
        btnDeleteAll = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        dateTo = new com.toedter.calendar.JDateChooser();
        btnSearchDates = new javax.swing.JButton();
        dateFrom = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtOneDraw = new javax.swing.JTextField();
        btnSearchId = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKliroseis = new javax.swing.JTable();

        jPanel2.setBackground(new java.awt.Color(110, 235, 222));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tzoker.jpg"))); // NOI18N

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/JOKERBALLS1.JPG"))); // NOI18N

        jButton1.setBackground(new java.awt.Color(80, 125, 140));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/erfolg.png"))); // NOI18N
        jButton1.setText("Διαχείριση δεδομένων ΤΖΟΚΕΡ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(128, 72, 38));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/analyse.png"))); // NOI18N
        jButton2.setText("Προβολή δεδομένων ΤΖΟΚΕΡ");

        jButton3.setBackground(new java.awt.Color(156, 76, 82));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/grafiken (1).png"))); // NOI18N
        jButton3.setText("Προβολή στατιστικών δεδομένων ΤΖΟΚΕΡ ");
        jButton3.setActionCommand("Προβολή στατιστικών δεδομένων ΤΖΟΚΕΡ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(138, 161, 27));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ausgang.png"))); // NOI18N
        jButton4.setText("Έξοδος");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(53, 57, 59));
        jPanel1.setPreferredSize(new java.awt.Dimension(644, 523));
        jPanel1.setLayout(null);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tzoker.jpg"))); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(0, 0, 910, 50);

        jPanel4.setBackground(new java.awt.Color(62, 72, 77));
        jPanel4.setLayout(null);

        jLabel9.setBackground(new java.awt.Color(228, 231, 237));
        jLabel9.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(228, 231, 237));
        jLabel9.setText("Διαχείριση Δεδομένων ΤΖΟΚΕΡ");
        jPanel4.add(jLabel9);
        jLabel9.setBounds(10, 0, 310, 40);

        jPanel5.setBackground(new java.awt.Color(62, 72, 77));
        jPanel5.setLayout(null);

        jLabel10.setBackground(new java.awt.Color(228, 231, 237));
        jLabel10.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(228, 231, 237));
        jLabel10.setText("Διαχείριση Δεδομένων ΤΖΟΚΕΡ");
        jPanel5.add(jLabel10);
        jLabel10.setBounds(140, 0, 310, 30);

        jPanel4.add(jPanel5);
        jPanel5.setBounds(0, 70, 580, 30);

        jButton10.setBackground(new java.awt.Color(155, 201, 222));
        jButton10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/return(16).png"))); // NOI18N
        jButton10.setText("    Μενού");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton10);
        jButton10.setBounds(901, 10, 109, 22);

        jPanel8.setBackground(new java.awt.Color(62, 72, 77));
        jPanel8.setLayout(null);

        jLabel12.setBackground(new java.awt.Color(228, 231, 237));
        jLabel12.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(228, 231, 237));
        jLabel12.setText("Διαχείριση Δεδομένων ΤΖΟΚΕΡ");
        jPanel8.add(jLabel12);
        jLabel12.setBounds(10, 5, 310, 30);

        jPanel9.setBackground(new java.awt.Color(62, 72, 77));
        jPanel9.setLayout(null);

        jLabel13.setBackground(new java.awt.Color(228, 231, 237));
        jLabel13.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(228, 231, 237));
        jLabel13.setText("Διαχείριση Δεδομένων ΤΖΟΚΕΡ");
        jPanel9.add(jLabel13);
        jLabel13.setBounds(140, 0, 310, 30);

        jPanel8.add(jPanel9);
        jPanel9.setBounds(0, 70, 580, 30);

        jButton11.setBackground(new java.awt.Color(155, 201, 222));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/return(16).png"))); // NOI18N
        jButton11.setText("    Μενού");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton11);
        jButton11.setBounds(550, 10, 100, 20);

        jPanel4.add(jPanel8);
        jPanel8.setBounds(0, 50, 660, 40);

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 50, 1040, 40);

        jPanel6.setBackground(new java.awt.Color(62, 72, 77));

        lblKat.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKat.setForeground(new java.awt.Color(228, 231, 237));
        lblKat.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblKat.setText("Κατηγορία");

        lblKatA.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatA.setForeground(new java.awt.Color(228, 231, 237));
        lblKatA.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatA.setText("5 + 1");

        lblKatB.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatB.setForeground(new java.awt.Color(228, 231, 237));
        lblKatB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatB.setText("5");

        lblKatC.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatC.setForeground(new java.awt.Color(228, 231, 237));
        lblKatC.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatC.setText("4 + 1");

        lblKatD.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatD.setForeground(new java.awt.Color(228, 231, 237));
        lblKatD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatD.setText("4");

        lblKatE.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatE.setForeground(new java.awt.Color(228, 231, 237));
        lblKatE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatE.setText("3 + 1");

        lblKatF.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatF.setForeground(new java.awt.Color(228, 231, 237));
        lblKatF.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatF.setText("3");

        lblKatG.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatG.setForeground(new java.awt.Color(228, 231, 237));
        lblKatG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatG.setText("2 + 1");

        lblEpit.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpit.setForeground(new java.awt.Color(228, 231, 237));
        lblEpit.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblEpit.setText("Αριθμός επιτυχειών ");

        lblEpitA.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitA.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitA.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitB.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitB.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitC.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitC.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitC.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitD.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitD.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitE.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitE.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitF.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitF.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitF.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblEpitG.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitG.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiC.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiC.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiC.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiG.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiG.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiD.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiD.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdi.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdi.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdi.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblKerdi.setText("Κέρδη ανά Επιτυχία");

        lblKerdiA.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiA.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiA.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiE.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiE.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiB.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiB.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiF.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiF.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiF.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKatH.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKatH.setForeground(new java.awt.Color(228, 231, 237));
        lblKatH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKatH.setText("1 + 1");

        lblEpitH.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblEpitH.setForeground(new java.awt.Color(228, 231, 237));
        lblEpitH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblKerdiH.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKerdiH.setForeground(new java.awt.Color(228, 231, 237));
        lblKerdiH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblEpit)
                            .addComponent(lblKerdi, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(lblKerdiA, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblKerdiB, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiC, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiD, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiE, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiF, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiG, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblKerdiH, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(lblEpitA, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitB, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitC, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitD, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitE, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitF, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitG, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblEpitH, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(lblKat, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(lblKatA, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatB, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatC, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatD, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatE, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatF, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatG, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblKatH, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKat, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatA, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatB, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatC, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatD, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatE, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatF, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatG, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKatH, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblEpitA, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpit, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitB, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitC, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitD, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitE, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitF, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitG, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEpitH, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(lblKerdi, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblKerdiB, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiA, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiC, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiD, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiE, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiF, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiG, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblKerdiH, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel6);
        jPanel6.setBounds(10, 410, 1000, 123);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/JOKERBALLS1.JPG"))); // NOI18N
        jPanel1.add(jLabel11);
        jLabel11.setBounds(0, 605, 1025, 60);

        jPanel3.setBackground(new java.awt.Color(62, 72, 77));

        lblKlirosi1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKlirosi1.setForeground(new java.awt.Color(228, 231, 237));
        lblKlirosi1.setText("Κλήρωση:");

        lblKlirosi.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblKlirosi.setForeground(new java.awt.Color(228, 231, 237));

        lblNikitria1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblNikitria1.setForeground(new java.awt.Color(228, 231, 237));
        lblNikitria1.setText("Τυχεροί αριθμοί:");

        lblNikitria.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblNikitria.setForeground(new java.awt.Color(228, 231, 237));

        lblJoker1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblJoker1.setForeground(new java.awt.Color(228, 231, 237));
        lblJoker1.setText("Τζόκερ:");

        lblJoker.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblJoker.setForeground(new java.awt.Color(228, 231, 237));

        lblHmerominia1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblHmerominia1.setForeground(new java.awt.Color(228, 231, 237));
        lblHmerominia1.setText("Ημερομηνία:");

        lblHmerominia.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        lblHmerominia.setForeground(new java.awt.Color(228, 231, 237));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblHmerominia1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNikitria1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNikitria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHmerominia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblJoker1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66)
                        .addComponent(lblJoker, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblKlirosi1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(lblKlirosi, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(651, 651, 651))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblKlirosi, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(lblHmerominia, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblKlirosi1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblHmerominia1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNikitria, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNikitria1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblJoker1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblJoker, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(620, 240, 390, 160);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tzoker.jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(650, 0, 390, 50);

        jPanel7.setBackground(new java.awt.Color(62, 72, 77));

        lblMessage.setBackground(new java.awt.Color(228, 231, 237));
        lblMessage.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        lblMessage.setForeground(new java.awt.Color(228, 231, 237));
        lblMessage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMessage, javax.swing.GroupLayout.DEFAULT_SIZE, 980, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblMessage, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel7);
        jPanel7.setBounds(10, 545, 1000, 50);

        jPanel10.setBackground(new java.awt.Color(62, 72, 77));

        jButton6.setBackground(new java.awt.Color(155, 201, 222));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/auf-speicherlaufwerk-herunterladen (16).png"))); // NOI18N
        jButton6.setText("       Αποθήκευση Δεδομένων");
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        btnDeleteOne.setBackground(new java.awt.Color(155, 201, 222));
        btnDeleteOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete(16).png"))); // NOI18N
        btnDeleteOne.setText("     Διαγραφή δεδομένων παιχνιδιού");
        btnDeleteOne.setActionCommand("Διαγραφή δεδομένων παιχνιδιού");
        btnDeleteOne.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnDeleteOne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteOneActionPerformed(evt);
            }
        });

        btnDeleteAll.setBackground(new java.awt.Color(155, 201, 222));
        btnDeleteAll.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete(16).png"))); // NOI18N
        btnDeleteAll.setText("     Διαγραφή δεδομένων παιχνιδιών εντός εύρους ημερομηνιών");
        btnDeleteAll.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnDeleteAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteAllActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDeleteAll)
                    .addComponent(jButton6)
                    .addComponent(btnDeleteOne))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDeleteOne)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDeleteAll)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel10);
        jPanel10.setBounds(620, 100, 390, 130);

        jPanel11.setBackground(new java.awt.Color(62, 72, 77));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(228, 231, 237));
        jLabel7.setText(" Από:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(228, 231, 237));
        jLabel14.setText("Έως:");

        dateTo.setBackground(new java.awt.Color(116, 135, 166));
        dateTo.setForeground(new java.awt.Color(116, 135, 166));
        dateTo.setToolTipText("");

        btnSearchDates.setBackground(new java.awt.Color(155, 201, 222));
        btnSearchDates.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lupe.png"))); // NOI18N
        btnSearchDates.setText("    Αναζήτηση");
        btnSearchDates.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchDatesActionPerformed(evt);
            }
        });

        dateFrom.setBackground(new java.awt.Color(116, 135, 166));
        dateFrom.setForeground(new java.awt.Color(116, 135, 166));
        dateFrom.setToolTipText("dd.MM.yyyy");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(228, 231, 237));
        jLabel15.setText("Επιλέξτε εύρος ημερομηνιών:");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnSearchDates, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel11Layout.createSequentialGroup()
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(dateTo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel11Layout.createSequentialGroup()
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(dateFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(dateFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateTo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearchDates, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        dateTo.getAccessibleContext().setAccessibleName("");
        dateFrom.getAccessibleContext().setAccessibleDescription("");

        jPanel1.add(jPanel11);
        jPanel11.setBounds(370, 100, 240, 130);

        jPanel12.setBackground(new java.awt.Color(62, 72, 77));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(228, 231, 237));
        jLabel6.setText("ID Παιχνιδιού:");

        txtOneDraw.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtOneDraw.setToolTipText("");
        txtOneDraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtOneDrawActionPerformed(evt);
            }
        });
        txtOneDraw.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtOneDrawKeyTyped(evt);
            }
        });

        btnSearchId.setBackground(new java.awt.Color(155, 201, 222));
        btnSearchId.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lupe.png"))); // NOI18N
        btnSearchId.setText("    Αναζήτηση");
        btnSearchId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchIdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(txtOneDraw)
                    .addComponent(btnSearchId, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtOneDraw, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSearchId, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel12);
        jPanel12.setBounds(190, 100, 170, 90);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(228, 231, 237));
        jLabel8.setText("Επιλέξτε  παιχνίδι:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(10, 100, 160, 20);

        tblKliroseis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Α/Α", "ΚΛΗΡΩΣΗ", "ΗΜΕΡΟΜΗΝΙΑ"
            }
        ));
        tblKliroseis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKliroseisMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKliroseis);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(10, 240, 600, 160);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1024, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 664, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Καλείται για να προσθέσει τα στοιχεία της κλήρωσης στον πίνακα των κληρώσεων
    private void fillTableWithSearchID(String strDraw) {
        String strDrawOpapReturn = opapApi.showOneDraw(strDraw);
        //Ελέγχει εάν το πεδίο της κλήρωσης δεν είναι κενό και εμφανίζει το ανάλογο μήνυμα.
        if(strDrawOpapReturn == ""){
            lblMessage.setText("Δώστε έγκυρο GAME ID!");
        }else{
            lblMessage.setText("Η αναζήτηση πέτυχε!");
        }
        //Αρχικοποιεί την παρουσία της συγκεκριμένης κλήρωσης
        klirosi oneKlirosi = new klirosi();
        //Ενημερώνει την παρούσα κλήρωση με του αριθμούς που περίεχει
        oneKlirosi.setNumbersFromJson(strDrawOpapReturn);
        //Ενημερώνει την παρούσα κλήρωση με τις κατηγορίες κερδών που περίεχει
        oneKlirosi.setCategorisFromJson(strDrawOpapReturn,oneKlirosi.getmydrawID());
        //oneKlirosi.showCategories();
        //Μετατρέπει την ημερομηνία κλήρωσης στον κατάλληλο τύπο
        DateFormat dfFrom = new SimpleDateFormat("dd.MM.yyyy"); 
        Date dateF = oneKlirosi.getmydrawDate();
        String stringDateFrom = dfFrom.format(dateF);
        Kliroseis.put(oneKlirosi.getmydrawID(), oneKlirosi);
        String arrOneDraw[]={"1", String.valueOf(oneKlirosi.getmydrawID()) + "", stringDateFrom};
        DefaultTableModel pinakasModel = (DefaultTableModel)tblKliroseis.getModel();
        //Προσθέτει στον πίνακα την Κλήρωση
        pinakasModel.addRow(arrOneDraw);
    }                                          

    //Καλείται για να προσθέσει τα στοιχεία κληρώσεων στον πίνακα των κληρώσεων μέσα σε ένα εύρος ημερομηνιών
    private void fillTableWithSearchDates(String dateFrom, String dateTo) {
        ArrayList<String> listDraws = new ArrayList<String>();
        //Καλείται η μέδοδος που παίρνει από το API του ΟΠΑΠ ως κείμενο τις κληρώσεις για ένα ημερομηνιακό διάστημα
        String strDrawsFromDAtes = opapApi.showDrawsFromDate_OnlyIDs(dateFrom, dateTo);
        Gson gson = new Gson();
        //Μετατρέπεται το κείμενο σε αντικείμενα με σκοπό να εισαχθούν σε λίστα
        JsonParser parser = new JsonParser();
        JsonElement jsonTree = parser.parse(strDrawsFromDAtes);
        if(jsonTree.isJsonArray()){
            JsonArray jsonarrayDraws = jsonTree.getAsJsonArray();
            if (jsonarrayDraws != null) {
                for (int i=0;i<jsonarrayDraws.size();i++){ 
                    listDraws.add(jsonarrayDraws.get(i).getAsString());
                }
            } 
        }
        //Ελέγχει εάν η λίστα των κληρώσεων είναι κενή
        if(listDraws.size() > 0){
            for (int i = 0; i < listDraws.size(); i++){
                //Καλείται η μέθοδος που εισάγει τις κληρώσεις στον πίνακα των κληρώσεων
                fillTableWithSearchID(listDraws.get(i).toString());
            }
        }

    }
    
    //Μέθοδος που καλείται για την εμφάνιση των δεδομένων της κλήρωσης στις ετικέτες της φόρμας
    private void showKlirosiData() {                                          
        DefaultTableModel pinakasModel = (DefaultTableModel)tblKliroseis.getModel();
        int idOfTable = parseInt(pinakasModel.getValueAt(tblKliroseis.getSelectedRow(), 1).toString());
        klirosi showKlirosi = Kliroseis.get(idOfTable);

        lblKlirosi.setText(String.valueOf(idOfTable));
        
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");        
        Date datemy = showKlirosi.getmydrawDate();
        String dateMyString = df.format(datemy);     
            
        lblHmerominia.setText(dateMyString);
        
        lblNikitria.setText(showKlirosi.showWinNumberWithComma());
        lblJoker.setText(String.valueOf(showKlirosi.getmyJoker()));
        
        katigoriaKerdous katA = showKlirosi.katigories.get(1);
        lblEpitA.setText(String.valueOf(katA.getcatNikites())); 
        lblKerdiA.setText(String.valueOf(katA.getcatKerdoi()));         

        katigoriaKerdous katB = showKlirosi.katigories.get(2);
        lblEpitB.setText(String.valueOf(katB.getcatNikites())); 
        lblKerdiB.setText(String.valueOf(katB.getcatKerdoi()));         
        
        katigoriaKerdous katC = showKlirosi.katigories.get(3);
        lblEpitC.setText(String.valueOf(katC.getcatNikites())); 
        lblKerdiC.setText(String.valueOf(katC.getcatKerdoi()));         

        katigoriaKerdous katD = showKlirosi.katigories.get(4);
        lblEpitD.setText(String.valueOf(katD.getcatNikites())); 
        lblKerdiD.setText(String.valueOf(katD.getcatKerdoi()));         

        katigoriaKerdous katE = showKlirosi.katigories.get(5);
        lblEpitE.setText(String.valueOf(katE.getcatNikites())); 
        lblKerdiE.setText(String.valueOf(katE.getcatKerdoi()));         

        katigoriaKerdous katF = showKlirosi.katigories.get(6);
        lblEpitF.setText(String.valueOf(katF.getcatNikites())); 
        lblKerdiF.setText(String.valueOf(katF.getcatKerdoi()));         

        katigoriaKerdous katG = showKlirosi.katigories.get(7);
        lblEpitG.setText(String.valueOf(katG.getcatNikites())); 
        lblKerdiG.setText(String.valueOf(katG.getcatKerdoi()));         

        katigoriaKerdous katH = showKlirosi.katigories.get(8);
        lblEpitH.setText(String.valueOf(katH.getcatNikites())); 
        lblKerdiH.setText(String.valueOf(katH.getcatKerdoi()));         
        
    }                                         

    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtOneDrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtOneDrawActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtOneDrawActionPerformed

    //Ενέργεια κατά το κλικ του πλήκτρου Επιστροφής στο Μενού
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        close();
        StartFrame startFrame = new StartFrame();
        startFrame.setVisible(true);
        startFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    //Ενέργεια κατά το κλικ του πλήκτρου αναζήτησης κλήρωσης
    private void btnSearchIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchIdActionPerformed
        DefaultTableModel model = (DefaultTableModel) tblKliroseis.getModel();
        //Καθαριμσός πίνακα κληρώσεων
        model.setRowCount(0);
        //Κλήση της μεθόδου που ενημερώνει τον πίνακα των κληρώσεων με την κλήρωση που έχει πληκτρολογηθεί
        fillTableWithSearchID(txtOneDraw.getText());
    }//GEN-LAST:event_btnSearchIdActionPerformed

    //Έλεγχος κατά την πληκτρολόγηση στο πεδίο που πληκτρολογείται η επιθυμητή κλήρωση
    private void txtOneDrawKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtOneDrawKeyTyped
        char c = evt.getKeyChar();
        //Επιτρεπόμενοι μόνο αριθμοί
        if(!Character.isDigit(c)){
            evt.consume();
        }
    }//GEN-LAST:event_txtOneDrawKeyTyped

    //Ενέργεια που γίνεται κατά το κλικ του ποντικιού στην γραμμή του πίνακα κληρώσεων
    private void tblKliroseisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKliroseisMouseClicked
        //Κλήση την μεθόδου ενημέρωσης των πεδίων ετικετών της φόρμας με τα δεδομένα της επιλεγμένης κλήρωσης
        showKlirosiData();
    }//GEN-LAST:event_tblKliroseisMouseClicked

    //Ενέργεια κατά το κλικ του πλήκτρου Διαγραφή δεδομένων παιχνιδιού
    private void btnDeleteOneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteOneActionPerformed
        //Stefanos:
        //Επιλογή αν θέλουμε σίγουρα να διαγράψουμε τα δεδομένα
        if(tblKliroseis.getRowCount()>0){
            if(tblKliroseis.getSelectedRowCount() == 1){
                //Εμφάνιση του μηνύματος επιβεβαίωσης διαγραφής
                int yesOrNo = JOptionPane.showConfirmDialog(null, "Είστε σίγουρος ότι θέλετε να διαγράψετε τα δεδομένα;", "ΠΡΟΣΟΧΗ!", JOptionPane.YES_NO_OPTION);
                if(yesOrNo == 0){
                    //Κλήση της μεθόδου διαγραφής μίας κλήρωσης από την ΒΔ
                    deleteAction();
                }
            } else{
                lblMessage.setText("Επιλέξτε από τον πίνακα μια κλήρωση την οποία θέλετε να διαγράψετε");
            }
        }else{
            lblMessage.setText("Αναζητήστε πρώτα τα δεδομένα τα οποία θέλετε να διαγράψετε!");
        }
    }//GEN-LAST:event_btnDeleteOneActionPerformed

    //Ενέργεια που καλείται για την διαγραφή μιάς κλήρωση από την ΒΔ
    public void deleteAction(){
            DefaultTableModel pinakasModel = (DefaultTableModel)tblKliroseis.getModel();
            int idOfTable = parseInt(pinakasModel.getValueAt(tblKliroseis.getSelectedRow(), 1).toString());
            klirosi selectedKlirosi = Kliroseis.get(idOfTable);
            //Κλήση της μεθόδου διαγραφής κλήρωσης από την ΒΔ
            doSqlActionToKlirosi(selectedKlirosi, 2);
            DefaultTableModel model = (DefaultTableModel) tblKliroseis.getModel();
            model.removeRow(tblKliroseis.getSelectedRow());
    }
    
    //Ενέργεια κατά το κλικ του πλήκτρου Διαγραφή Όλων
    private void btnDeleteAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteAllActionPerformed
        //Επιλογή αν θέλουμε σίγουρα να διαγράψουμε τα δεδομένα
        if(tblKliroseis.getRowCount()>0){
            if(DateSettingIsOk == true){
                //Εμφάνιση του μηνύματος επιβεβαίωσης διαγραφής
                int yesOrNo = JOptionPane.showConfirmDialog(null, "Είστε σίγουρος ότι θέλετε να διαγράψετε τα δεδομένα;", "ΠΡΟΣΟΧΗ!", JOptionPane.YES_NO_OPTION);
                if(yesOrNo == 0){
                    //Κλήση της μεθόδου διαγραφής όλων των εγγραφών από την ΒΔ
                    deleteAllAction();
                }
            }else{
                lblMessage.setText("Επιλέξτε πρώτα ποιο εύρος ημερομηνιών θέλετε να διαγράψετε ");
            }    
        }else{
            lblMessage.setText("Δεν υπάρχουν δεδομένα στον πίνακα για να διαγραφτούν!");
        }
    }//GEN-LAST:event_btnDeleteAllActionPerformed

    //Ενέργεια που καλείται για την διαγραφή όλων των κληρώσεων από την βάση δεδομένων
    public void deleteAllAction(){
        DefaultTableModel pinakasModel = (DefaultTableModel)tblKliroseis.getModel();
        //Ελέγχει εάν ο πίνακας των κληρώσεων είναι κενός
        if(tblKliroseis.getRowCount()>0){
            for (int i = 0; i < tblKliroseis.getRowCount(); i++){
                int idOfTable = parseInt(pinakasModel.getValueAt(i, 1).toString());
                klirosi forKlirosi = Kliroseis.get(idOfTable);
                //Κλήση της μεθόδου διαγραφής την ΒΔ
                doSqlActionToKlirosi(forKlirosi, 2);
            }
            tblKliroseis.setModel(new DefaultTableModel(null,new String[]{"A/A", "ΚΛΗΡΩΣΗ", "ΗΜΕΡΟΜΗΝΙΑ"}));
        }    
    }

    //Μέθοδος που κάνει ενέργειες στην ΒΔ των κληρώσεων, mode=1 Αποθήκευση, mode=2 Διαγραφή
    private void doSqlActionToKlirosi(klirosi showKlirosi, int mode) {
        String doAction = "";
        if(mode==1){//1=save,2=delete
            //Κλήση της μεθόδου αποθήκευσης στην ΒΔ
            doAction = sqlKliroseis.saveKlirosi_toDB(showKlirosi);
            if(doAction == "Y"){
                lblMessage.setText("Η Αποθήκευση ήταν επιτυχής!");
            }else{
                lblMessage.setText("Η Αποθήκευση ΔΕΝ ήταν επιτυχής, τα δεδομένα υπάρχουν ήδη στην Βάση Δεδομένων!");
            }
        }else if(mode==2){//1=save,2=delete
            //Κλήση της μεθόδου διαγραφής στην ΒΔ
            doAction = sqlKliroseis.deleteKlirosi_fromDB(showKlirosi); 
            String eq1 = "1111";
            String eq2 = "";
            if(doAction.equals(eq1) == true){                
                lblMessage.setText("Η Διαγραφή ήταν επιτυχής!");
            }else{
                lblMessage.setText("<html>Ίσος κάποια δεδομένα να μην υπήρχαν από πριν στην ΒΔ για να μπορέσουν να διαγραφτούν<br/>(Αυτά που υπήρχαν έχουν διαγραφτεί)<html>");
            }
        }
    }
    
    //Ενέργεια που γίνεται κατά το κλίκ του πλήκτρου Αποθήκευση
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        DefaultTableModel pinakasModel = (DefaultTableModel)tblKliroseis.getModel();
        //Ελέγχει εάν ο πίνακας των κληρώσεων είναι κενός
        if(tblKliroseis.getRowCount()>0){
            //Βρόγχος σε όλες τις γραμμές του πίνακα των κληρώσεων με σκοπό την αποθήκευση στην ΒΔ
            for (int i = 0; i < tblKliroseis.getRowCount(); i++){
                int idOfTable = parseInt(pinakasModel.getValueAt(i, 1).toString());
                klirosi forKlirosi = Kliroseis.get(idOfTable);
                //Κλήση της μεθόδου που κάνει ενέργειες στην ΒΔ των κληρώσεων, με δείκτη 1 δηλαδή Αποθήκευση
                doSqlActionToKlirosi(forKlirosi, 1);
            }
        }else{
            lblMessage.setText("Αναζητήστε τα δεδομένα που θέλετε να αποθηκεύσετε");
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void btnSearchDatesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchDatesActionPerformed
        Date fromD = dateFrom.getDate();
        Date toD = dateTo.getDate();
        int intFromd = 0;
        int intToD = 0;
        int intTodayD = 0;
        //Έλεγχος εαν τα πεδία ημερομηνίας είναι κενά
        if(fromD != null && toD != null){
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            String stringTodaysDate = dtf.format(LocalDateTime.now());
            SimpleDateFormat formatFromDate = new SimpleDateFormat("yyyyMMdd");      
            String stringFromDay = formatFromDate.format(fromD);
            SimpleDateFormat formatToDay = new SimpleDateFormat("yyyyMMdd");
            String stringToDay = formatToDay.format(toD);
            intFromd = Integer.parseInt(stringFromDay);
            intToD = Integer.parseInt(stringToDay);
            intTodayD = Integer.parseInt(stringTodaysDate);
        }
        if(fromD != null && toD != null){
            //Έλεγχος εαν το πεδίο ημερομνίας Έως είναι μεγαλύτερο από το πεδίο Από
            if(intFromd > intTodayD || intToD > intTodayD){
                lblMessage.setText("Η ημερομηνία που επιλέχτηκε είναι μεγαλύτερη από την σημερινή");
            }else if(toD.compareTo(fromD)>=0){
                lblMessage.setText("Η αναζήτηση Πέτυχε!");
                SimpleDateFormat format_fromD = new SimpleDateFormat("yyyy-MM-dd");
                String strFromD = format_fromD.format(fromD); 
                SimpleDateFormat format_toD = new SimpleDateFormat("yyyy-MM-dd");
                String strToDate = format_toD.format(toD);
                //Μηδενίζει προιγούμενα αποτελέσματα από τον πίνακα
                DefaultTableModel model = (DefaultTableModel) tblKliroseis.getModel();
                //Καθαρίζει τον πίνακα των κληρώσεων
                model.setRowCount(0);
                //Καλεί την μέθοδο που γεμίζει τον πίνακα των κληρώσεων
                fillTableWithSearchDates(strFromD, strToDate);
                DateSettingIsOk = true;
            } else {
                lblMessage.setText("Πρέπει η Από ημερομηνία να μην είναι μεγαλύτερη από την Έως!");
            }
        } else {
            lblMessage.setText("Πρέπει να συμπληρώσετε ημερομηνίες!");
        }
    }//GEN-LAST:event_btnSearchDatesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowDataForEachMonthR3_1().setVisible(true);
            }
        });
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeleteAll;
    private javax.swing.JButton btnDeleteOne;
    private javax.swing.JButton btnSearchDates;
    private javax.swing.JButton btnSearchId;
    private com.toedter.calendar.JDateChooser dateFrom;
    private com.toedter.calendar.JDateChooser dateTo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblEpit;
    private javax.swing.JLabel lblEpitA;
    private javax.swing.JLabel lblEpitB;
    private javax.swing.JLabel lblEpitC;
    private javax.swing.JLabel lblEpitD;
    private javax.swing.JLabel lblEpitE;
    private javax.swing.JLabel lblEpitF;
    private javax.swing.JLabel lblEpitG;
    private javax.swing.JLabel lblEpitH;
    private javax.swing.JLabel lblHmerominia;
    private javax.swing.JLabel lblHmerominia1;
    private javax.swing.JLabel lblJoker;
    private javax.swing.JLabel lblJoker1;
    private javax.swing.JLabel lblKat;
    private javax.swing.JLabel lblKatA;
    private javax.swing.JLabel lblKatB;
    private javax.swing.JLabel lblKatC;
    private javax.swing.JLabel lblKatD;
    private javax.swing.JLabel lblKatE;
    private javax.swing.JLabel lblKatF;
    private javax.swing.JLabel lblKatG;
    private javax.swing.JLabel lblKatH;
    private javax.swing.JLabel lblKerdi;
    private javax.swing.JLabel lblKerdiA;
    private javax.swing.JLabel lblKerdiB;
    private javax.swing.JLabel lblKerdiC;
    private javax.swing.JLabel lblKerdiD;
    private javax.swing.JLabel lblKerdiE;
    private javax.swing.JLabel lblKerdiF;
    private javax.swing.JLabel lblKerdiG;
    private javax.swing.JLabel lblKerdiH;
    private javax.swing.JLabel lblKlirosi;
    private javax.swing.JLabel lblKlirosi1;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblNikitria;
    private javax.swing.JLabel lblNikitria1;
    private javax.swing.JTable tblKliroseis;
    private javax.swing.JTextField txtOneDraw;
    // End of variables declaration//GEN-END:variables

}
