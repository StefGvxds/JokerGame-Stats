
package Forms;

import javax.swing.JFrame;

/**
 *
 *Gavouchidis Stefanοs
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */
public class ShowDataForEachMonthR3_1 extends javax.swing.JFrame {

    //Αρχικοπίηση τις μεταβλητές της φόρμας
    private int yaerData = 0;
    private int monthData = 0;
    private String monthName = "";
    private int kliroseis =0;
    private int jackpots =0;
    private double posaDianem =0;
    
    public ShowDataForEachMonthR3_1() {
        initComponents();
        //Το μέγεθος του Παράθυρου Θα έχει σταθερό μέγεθος και δεν θα αλλάζει
        setSize(585,455);
        //Καθορίζει σε ποιο σημείο της οθόνης θα ανοίξει το παράθυρο 
        setLocationByPlatform(true);
        //Δεν αφήνει στον χρήστη να αλλάξει το μέγεθος του παραθύρου 
        setResizable(false);
        //Αν κλήσει αυτό το παράθυρο να μην κλείσει το GUI-R3 (ShowDataR3)
        setDefaultCloseOperation(ShowDataForEachMonthR3_1.DISPOSE_ON_CLOSE);           
    }
   
    //Μέθοδος για την ενημέρωση των μεταβλητών της φόρμας
    public void setDates(int yearNumber, int monthNumber, String monthOnoma){
        yaerData = yearNumber;
        monthData = monthNumber;
        monthName = monthOnoma;
    }

    //Μέθοδος για την ενημέρωση των μεταβλητών σχετικά με τα επιλεγμένα δεδομένα
    public void setDedomena(int MyKliroseis, int MyJackpots, double MyPosaDianem){
        kliroseis = MyKliroseis;
        jackpots = MyJackpots;
        posaDianem = MyPosaDianem;
    }

    //Μέθοδος για την ενημέρωση των ετικετών
    public void setLabels(){
        lblMinas.setText(monthName);
        lblEtos.setText(String.valueOf(yaerData));
        lblKliroseis.setText(String.valueOf(kliroseis));
        lbJackpots.setText(String.valueOf(jackpots));
        lblDiamemithikan.setText(String.valueOf(posaDianem)+" €");
    }    
    
    //Ανάλογα με τον μήνα που επιλέγουμε από την λίστα αλλάζει και η ονομασία του μήνα στο GUI 3_1
    public int changeMonthName(int month){
        int monthReturn = 0;
        if(month == 0){
            lblMinas.setText("Ιανουάριος");
        }else if(month == 1){
            lblMinas.setText("Φεβρουάριος");
        }else if(month == 2){
            lblMinas.setText("Μάρτιος");
        }else if(month == 3){
            lblMinas.setText("Απρίλιος");
        }else if(month == 4){
            lblMinas.setText("Μάιος");
        }else if(month == 5){
            lblMinas.setText("Ιούνιος");
        }else if(month == 6){
            lblMinas.setText("Ιούλιος");
        }else if(month == 7){
            lblMinas.setText("Αύγουστος");
        }else if(month == 8){
            lblMinas.setText("Σεπτέμβριος");
        }else if(month == 9){
            lblMinas.setText("Οκτώμβριος");
        }else if(month == 10){
            lblMinas.setText("Νοέμβριος");
        }else if(month == 11){
            lblMinas.setText("Δεκέμβριος");
        }
        return monthReturn;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lblEtos = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lblMinas = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        lblKliroseis = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        lbJackpots = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        lblDiamemithikan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel6.setBackground(new java.awt.Color(53, 57, 59));
        jPanel6.setMinimumSize(new java.awt.Dimension(590, 0));
        jPanel6.setPreferredSize(new java.awt.Dimension(590, 523));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tzoker.jpg"))); // NOI18N

        jPanel7.setBackground(new java.awt.Color(62, 72, 77));
        jPanel7.setLayout(null);

        jLabel11.setBackground(new java.awt.Color(228, 231, 237));
        jLabel11.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(228, 231, 237));
        jLabel11.setText("Προβολή Δεδομένων ΤΖΟΚΕΡ για:");
        jPanel7.add(jLabel11);
        jLabel11.setBounds(10, 5, 430, 30);

        jButton12.setBackground(new java.awt.Color(155, 201, 222));
        jButton12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete(16).png"))); // NOI18N
        jButton12.setText("     κλείσιμο");
        jButton12.setActionCommand("κλείσιμο");
        jButton12.setPreferredSize(new java.awt.Dimension(109, 35));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton12);
        jButton12.setBounds(440, 10, 130, 22);

        jLabel5.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(228, 231, 237));
        jLabel5.setText("Έτος:");
        jPanel7.add(jLabel5);
        jLabel5.setBounds(260, 40, 70, 40);

        lblEtos.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        lblEtos.setForeground(new java.awt.Color(237, 150, 19));
        jPanel7.add(lblEtos);
        lblEtos.setBounds(320, 40, 80, 40);

        jLabel17.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(228, 231, 237));
        jLabel17.setText("Μήνας:");
        jPanel7.add(jLabel17);
        jLabel17.setBounds(10, 40, 70, 40);

        lblMinas.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        lblMinas.setForeground(new java.awt.Color(237, 150, 19));
        jPanel7.add(lblMinas);
        lblMinas.setBounds(90, 40, 140, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/JOKERBALLS1.JPG"))); // NOI18N

        jPanel1.setBackground(new java.awt.Color(62, 72, 77));

        jLabel15.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(228, 231, 237));
        jLabel15.setText("Συνολικά Παιχνίδια:");

        lblKliroseis.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        lblKliroseis.setForeground(new java.awt.Color(237, 150, 19));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblKliroseis, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblKliroseis, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(62, 72, 77));

        jLabel18.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(228, 231, 237));
        jLabel18.setText("Συνολικά ΤΖΑΚ-ΠΟΤ:");

        lbJackpots.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        lbJackpots.setForeground(new java.awt.Color(237, 150, 19));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbJackpots, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbJackpots, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(62, 72, 77));

        jLabel19.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(228, 231, 237));
        jLabel19.setText("Συνολικά Χρήματα:");

        lblDiamemithikan.setFont(new java.awt.Font("Verdana Pro Cond Black", 1, 18)); // NOI18N
        lblDiamemithikan.setForeground(new java.awt.Color(237, 150, 19));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDiamemithikan, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDiamemithikan, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 910, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 591, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Ενέργεια κατά το κλίκ του πλήκτρου κλεισίματος
    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton12ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowDataForEachMonthR3_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowDataForEachMonthR3_1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton12;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JLabel lbJackpots;
    private javax.swing.JLabel lblDiamemithikan;
    private javax.swing.JLabel lblEtos;
    private javax.swing.JLabel lblKliroseis;
    private javax.swing.JLabel lblMinas;
    // End of variables declaration//GEN-END:variables
}
