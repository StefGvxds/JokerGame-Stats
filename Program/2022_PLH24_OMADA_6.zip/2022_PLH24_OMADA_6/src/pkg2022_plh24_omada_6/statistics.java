
package pkg2022_plh24_omada_6;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

//Κλάση στατιστικών
public class statistics {

public Date statsDateFrom;
public Date statsDateTo;

public int statsKliroseis;

public Map<Integer, Integer> emfaniseisArithmon = new HashMap<Integer, Integer>();
public Map<Integer, Integer> emfaniseisJoker = new HashMap<Integer, Integer>();

    //Μέθοδος που εμφανίζει στην κονσόλα τις εμφανίσεις των αριθμών
    public void showEmfaniseisArithmon(){
        for (Map.Entry<Integer, Integer> arithmmos : emfaniseisArithmon.entrySet()){
            int oArithmos = arithmmos.getKey();
            int oiEmfaniseis = arithmmos.getValue();
            System.out.println("Ο αριθμός " + oArithmos + " έχει " + oiEmfaniseis + " εμφανίσεις.");
        }
    }

    //Μέθοδος που διαβάζει το JSON κείμενο για να πάρει τα στατιστικά στοιχεία από τον ΟΠΑΠ API
    public void setStatsFromJson(String opapJsonStatisticsString){
        
        String KlirosiDate = "";
        ArrayList<Integer> listWinningNumbers = new ArrayList<Integer>();
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonElement jsonTree = parser.parse(opapJsonStatisticsString);
        if(jsonTree.isJsonObject()){
            JsonObject jsonObject = jsonTree.getAsJsonObject();
            JsonElement eHeader = jsonObject.get("header");
            JsonElement eNumbers = jsonObject.get("numbers");
            JsonElement eJokers = jsonObject.get("bonusNumbers");
            
            if(eNumbers.isJsonArray()){
                JsonArray jsonarrayAritmoi = eNumbers.getAsJsonArray();
                if (jsonarrayAritmoi != null) {
                    for (int i=0;i<jsonarrayAritmoi.size();i++){ 
                        if(jsonarrayAritmoi.get(i).isJsonObject()){
                            JsonObject oNum = jsonarrayAritmoi.get(i).getAsJsonObject();
                            JsonElement emfaniseis = oNum.get("occurrences");
                            JsonElement arithmos = oNum.get("number");
                            //Ενημερώνει την λίστα με τις εμφανίσεις των αριθμών
                            emfaniseisArithmon.put(arithmos.getAsInt(), emfaniseis.getAsInt());
                        }
                    } 
                }
            }
            
            if(eJokers.isJsonArray()){
                JsonArray jsonarrayJokers = eJokers.getAsJsonArray();
                if (jsonarrayJokers != null) {
                    for (int i=0;i<jsonarrayJokers.size();i++){ 
                        if(jsonarrayJokers.get(i).isJsonObject()){
                            JsonObject oNumJ = jsonarrayJokers.get(i).getAsJsonObject();
                            JsonElement emfaniseisJ = oNumJ.get("occurrences");
                            JsonElement arithmosJ = oNumJ.get("number");
                            //Ενημερώνει την λίστα με τις εμφανίσεις των αριθμών Joker
                            emfaniseisJoker.put(arithmosJ.getAsInt(), emfaniseisJ.getAsInt());
                        }
                    } 
                }
            }
            
            if(eHeader.isJsonObject()){
                //Ενημερώνει τις μεταβλητές των ημερομηνιών και της κλήρωσης
                JsonObject headerObject = eHeader.getAsJsonObject();
                JsonElement dateFrom = headerObject.get("dateFrom");
                long longDateFrom = dateFrom.getAsLong();
                statsDateFrom = new Date(longDateFrom);
                JsonElement dateTo = headerObject.get("dateTo");
                long longDateTo = dateTo.getAsLong();
                statsDateTo = new Date(longDateTo);
                JsonElement drawCount = headerObject.get("drawCount");
                int kliroseis = drawCount.getAsInt();
                statsKliroseis = kliroseis;
                System.out.println("longDateFrom: "+longDateFrom);
                System.out.println("longDateTo: "+longDateTo);
                System.out.println("kliroseis: "+kliroseis);
            }
        }
    } //end of method: setNumbersFromJson
}
