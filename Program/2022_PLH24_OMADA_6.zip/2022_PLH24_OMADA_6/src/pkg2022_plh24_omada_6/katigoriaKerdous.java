
package pkg2022_plh24_omada_6;

import java.util.ArrayList;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

public class katigoriaKerdous {

    private int mydrawID;   
    private int catType;
    private double catKerdoi;
    private long catNikites;
    private double catDianmithikan;
    private double catJackpot;

    //Αρχικοποίηση της κλάσης κατά την δημιουργία
    public katigoriaKerdous(int mydrawID, int catType, double catKerdoi, long catNikites) {
        this.mydrawID = mydrawID;
        this.catType = catType;
        this.catKerdoi = catKerdoi;
        this.catNikites = catNikites;
    }
    
   public int getmydrawID(){return mydrawID;} 
   public void setmydrawID(int mydrawID){this.mydrawID=mydrawID;}
   
   
   public int getcatType(){return catType;} 
   public void setcatType(int catType){this.catType=catType;}
   
   
   public double getcatKerdoi(){return catKerdoi;} 
   public void setcatKerdoi(double catKerdoi ){this.catKerdoi=catKerdoi;}
   
   
   public long getcatNikites(){return catNikites;} 
   public void setcatNikites(long catNikites){this.catNikites=catNikites;}
   
   public double getcatDianmithikan(){return catDianmithikan;} 
   public void setcatDianmithikan(double catDianmithikan){this.catDianmithikan=catDianmithikan;}
   
   public double getcatJackpot(){return catJackpot ;} 
   public void setcatJackpot(double catJackpot ){this.catJackpot=catJackpot;}
   
   
}
