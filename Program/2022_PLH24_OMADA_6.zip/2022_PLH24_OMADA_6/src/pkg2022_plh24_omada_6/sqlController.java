
package pkg2022_plh24_omada_6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

//Η κλάση που διατηρεί τα στοιχεία σύνδεσης με την βάση δεδομένων
public class sqlController {
    
    //Η μέθοδος που δημιουργεί σύνδεση με την ΒΔ
    public static Connection connect(){
        String connectionString = "jdbc:derby://localhost/omada6db;user=omada6;password=omada6;create=true";
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(connectionString);
            //System.out.println("OK");
        } catch (SQLException e) {
            //System.out.println("ERROR"+e.getMessage());
        }
        return connection;
    }
}
