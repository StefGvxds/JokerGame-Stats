
package pkg2022_plh24_omada_6;

import java.io.IOException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

//Κλάση που χρησιμοποιείται για την άντληση δεδομένων από το ΟΠΑΠ API
public class opapApi {
    
    //Μέθοδος που παίρνει τα στοιχεία μίας κλήρωσης από το ΟΠΑΠ API
    public static String showOneDraw(String drawId) {
        String urlToCall = "https://api.opap.gr/draws/v3.0/5104/" + drawId;
        String DrawIdsReturn = "";
        OkHttpClient client=new OkHttpClient();
        Request request = new Request.Builder().url(urlToCall).build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseString=response.body().string();
                DrawIdsReturn = responseString ;
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }           
        return DrawIdsReturn;
    }
      
    //Μέθοδος που παίρνει τα στοιχεία κληρώσεων για ένα διάστημα ημερομηνιών από το ΟΠΑΠ API
    public static String showDrawsFromDate(String fromdate, String todate) {
        String urlToCall = "https://api.opap.gr/draws/v3.0/5104/draw-date/"+fromdate+"/"+todate;
        String DrawIdsReturn = "";
        OkHttpClient client=new OkHttpClient();
        Request request = new Request.Builder().url(urlToCall).build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseString=response.body().string();
                DrawIdsReturn = responseString ;
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }           
        return DrawIdsReturn;
    }    
      
    //Μέθοδος που παίρνει μόνο τον αριθμό των κληρώσεων για ένα διάστημα ημερομηνιών από το ΟΠΑΠ API
    public static String showDrawsFromDate_OnlyIDs(String fromdate,String todate) {
        String urlToCall = "https://api.opap.gr/draws/v3.0/5104/draw-date/"+fromdate+"/"+todate+"/draw-id";
        String DrawIdsReturn = "";
        OkHttpClient client=new OkHttpClient();
        Request request = new Request.Builder().url(urlToCall).build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseString=response.body().string();
                DrawIdsReturn = responseString ;
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }           
        return DrawIdsReturn;
    }  
    
    //Μέθοδος που παίρνει στατιστικά στοιχεία από το ΟΠΑΠ API
    public static String showStatistics() {
        String urlToCall = "https://api.opap.gr/games/v1.0/5104/statistics";
        String OpapStatistics = "";
        OkHttpClient client=new OkHttpClient();
        Request request = new Request.Builder().url(urlToCall).build();
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseString=response.body().string();
                OpapStatistics = OpapStatistics + responseString ;
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }           
        return OpapStatistics;
    }

}
