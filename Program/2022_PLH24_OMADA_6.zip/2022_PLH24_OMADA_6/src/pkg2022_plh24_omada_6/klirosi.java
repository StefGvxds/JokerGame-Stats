
package pkg2022_plh24_omada_6;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

//Κλάση που κρατάει τα δεδομένα για κάθε κλήρωση
public class klirosi {

   private int mydrawID;
   Date mydrawDate;
   private int myJokerNumber;
   public ArrayList<Integer> myWinningNumbers = new ArrayList<Integer>();
  
   //Λίστα με τα δεδομένα των κατηγοριών της κάθε κλήρωσης
   public Map<Integer, katigoriaKerdous> katigories = new HashMap<Integer, katigoriaKerdous>();
   
   public int getmydrawID(){return mydrawID;} 
   public void setmydrawID(int mydrawID){this.mydrawID=mydrawID;}
 
   public int getmyJoker(){return myJokerNumber;} 
   public void setmyJoker(int myJokerNumber){this.myJokerNumber=myJokerNumber;}
 
   public Date getmydrawDate(){return mydrawDate;} 
   public void setmydrawDate(Date mydrawDate){this.mydrawDate=mydrawDate;}
 
    public void showCategories(){
        for (Map.Entry<Integer, katigoriaKerdous> drawCat : katigories.entrySet()){
            katigoriaKerdous dKatigoriaKerdous = drawCat.getValue();
        }
    }
    
    //Μέθοδος που εμφανίζει τους νικητήριους αριθμούς χωρισμένους με κόμα.
    public String showWinNumberWithComma(){
        String returnStr = "";
        for (int i = 0; i < myWinningNumbers.size(); i++){
            returnStr = returnStr + myWinningNumbers.get(i).toString();
            if(i!=myWinningNumbers.size()-1){
                returnStr = returnStr + ", ";
            }
        }
        return returnStr;
    }
    
    //Η μέθοδος που ενημερώνει τα δεδομένα των κατηγοριών της κλάσης από το Json κείμενο
    public void setCategorisFromJson(String opapJsonDrawString,int mydrawID){
        ArrayList<Integer> listWinningNumbers = new ArrayList<Integer>();
        int jokerNumber = 0;
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonElement jsonTree = parser.parse(opapJsonDrawString);
        if(jsonTree.isJsonObject()){
            JsonObject jsonObject = jsonTree.getAsJsonObject();
            JsonElement prizeCategories = jsonObject.get("prizeCategories");
            if(prizeCategories.isJsonArray()){
                JsonArray jsonarrayCategories = prizeCategories.getAsJsonArray();
                if (jsonarrayCategories != null) {
                    for (int i=0;i<jsonarrayCategories.size();i++){
                        if(jsonarrayCategories.get(i).isJsonObject()){
                            JsonObject catObj = jsonarrayCategories.get(i).getAsJsonObject();
                            JsonElement catId = catObj.get("id");
                            JsonElement catKerdoi = catObj.get("divident");
                            JsonElement catNikites = catObj.get("winners");
                            JsonElement catDianmithikan = catObj.get("distributed");
                            JsonElement catJackpot = catObj.get("jackpot");
                            katigoriaKerdous tmtkatigoria = new katigoriaKerdous(mydrawID,catId.getAsInt(),catKerdoi.getAsDouble(),catNikites.getAsLong());
                            tmtkatigoria.setcatDianmithikan(catDianmithikan.getAsDouble());
                            tmtkatigoria.setcatJackpot(catJackpot.getAsDouble());
                            katigories.put(catId.getAsInt(), tmtkatigoria);
                        }
                    }
                }
            }
        }
    }

    //Η μέθοδος που ενημερώνει τα νούμερα της κλάσης από το Json κείμενο
    public void setNumbersFromJson(String opapJsonDrawString){
        int klirosiId = 0;
        int jokerNumber = 0;
        Date KlirosiImerominia;
        String KlirosiDate = "";
        ArrayList<Integer> listWinningNumbers = new ArrayList<Integer>();
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonElement jsonTree = parser.parse(opapJsonDrawString);
        if(jsonTree.isJsonObject()){
            JsonObject jsonObject = jsonTree.getAsJsonObject();
            JsonElement drawId = jsonObject.get("drawId");
            klirosiId = drawId.getAsInt();
            mydrawID=klirosiId;
            JsonElement drawTime = jsonObject.get("drawTime");
            long longDrawDate = drawTime.getAsLong();
            KlirosiImerominia = new Date(longDrawDate);
            mydrawDate=KlirosiImerominia;
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            KlirosiDate = format.format(KlirosiImerominia); 
            JsonElement winningNumbers = jsonObject.get("winningNumbers");
            if(winningNumbers.isJsonObject()){
                JsonObject f2Obj = winningNumbers.getAsJsonObject();
                JsonElement arithmoi = f2Obj.get("list");
                if(arithmoi.isJsonArray()){
                    JsonArray jsonarrayAritmoi = arithmoi.getAsJsonArray();
                    if (jsonarrayAritmoi != null) {
                        for (int i=0;i<jsonarrayAritmoi.size();i++){ 
                            listWinningNumbers.add(jsonarrayAritmoi.get(i).getAsInt());
                            myWinningNumbers.add(jsonarrayAritmoi.get(i).getAsInt());
                        } 
                    }
                }
                JsonElement joker = f2Obj.get("bonus");
                if(joker.isJsonArray()){
                    JsonArray jsonarrayJoker = joker.getAsJsonArray();
                    if (jsonarrayJoker != null) {
                        jokerNumber = jsonarrayJoker.get(0).getAsInt();
                    }
                }
            }
        }
        myJokerNumber=jokerNumber;
    } //end of method: setNumbersFromJson
    
}