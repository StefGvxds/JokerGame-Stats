
package pkg2022_plh24_omada_6;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//Η κλάση που διατηρεί όλες τις εντολές προς την βάση δεδομένων.
public class sqlKliroseis {

    //Μέθοδος που επιστρέφει από την ΒΔ τους αριθμούς Joker με την μεγαλύτερη συχνότητα
    public static HashMap<Integer, Integer> showDatesjokerTop(String fDate, String tDate, int topLines){
        HashMap<Integer, Integer> tmpMap = new HashMap<Integer, Integer>();
        int returnCat = 0;
        Integer returnMetritis = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String metritisJokerSQL = "";
            metritisJokerSQL  += " SELECT OMADA6.JOKERNUMSJOKER.JOKER AS JOKERCOUNT, COUNT(*) AS METRITIS  FROM OMADA6.JOKERNUMSJOKER ";
            metritisJokerSQL  += " inner join OMADA6.JOKERDRAWS on OMADA6.JOKERNUMSJOKER.DRAWID = OMADA6.JOKERDRAWS.DRAWID ";
            metritisJokerSQL  += "  WHERE OMADA6.JOKERDRAWS.DRAWTIME >= '"+fDate+"' AND OMADA6.JOKERDRAWS.DRAWTIME <= '"+tDate+"' ";
            metritisJokerSQL  += " group by OMADA6.JOKERNUMSJOKER.JOKER ORDER BY COUNT(*) DESC FETCH FIRST "+topLines+" ROWS ONLY ";
            PreparedStatement preparedStatement = connection.prepareStatement(metritisJokerSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnCat = rsEtos.getInt("JOKERCOUNT");
               returnMetritis = rsEtos.getInt("METRITIS");
               tmpMap.put(returnCat, returnMetritis);
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των μετρημένων " + ex.toString());
        }
        return tmpMap;   
    }

    //Μέθοδος που επιστρέφει από την ΒΔ τους αριθμούς με την μεγαλύτερη συχνότητα
    public static HashMap<Integer, Integer> showDatesNumbersTop(String fDate, String tDate, int topLines){
        HashMap<Integer, Integer> tmpMap = new HashMap<Integer, Integer>();
        int returnCat = 0;
        int returnMetritis = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String metritisNumbersSQL = "";
            metritisNumbersSQL  += " SELECT OMADA6.JOKERNUMSNORMAL.NUMBER AS ARITHMOSCOUNT, COUNT(*) AS METRITIS  FROM OMADA6.JOKERNUMSNORMAL ";
            metritisNumbersSQL  += " inner join OMADA6.JOKERDRAWS on OMADA6.JOKERNUMSNORMAL.DRAWID = OMADA6.JOKERDRAWS.DRAWID ";
            metritisNumbersSQL  += "  WHERE OMADA6.JOKERDRAWS.DRAWTIME >= '"+fDate+"' AND OMADA6.JOKERDRAWS.DRAWTIME <= '"+tDate+"' ";
            metritisNumbersSQL  += " group by OMADA6.JOKERNUMSNORMAL.NUMBER ORDER BY COUNT(*) DESC FETCH FIRST "+topLines+" ROWS ONLY ";
            PreparedStatement preparedStatement = connection.prepareStatement(metritisNumbersSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnCat = rsEtos.getInt("ARITHMOSCOUNT");
               returnMetritis = rsEtos.getInt("METRITIS");
               tmpMap.put(returnCat, returnMetritis);
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των μετρημένων " + ex.toString());
        }
        return tmpMap;   
    }
    
    //Μέθοδος που επιστρέφει από την ΒΔ τους μέσους όρους ανα κατηγορία κερδών για ένα ημερολογιακό διάστημα
    public static HashMap<Integer, Double> showDatesDianemithikanAverage(String fDate, String tDate){
        HashMap<Integer, Double> tmpMap = new HashMap<Integer, Double>();
        int returnCat = 0;
        double returnAvg = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String DianemithikanSQL = "";
            DianemithikanSQL  += " SELECT OMADA6.JOKERWINCATEGORIES.TYPE AS DIANCAT, AVG(OMADA6.JOKERWINCATEGORIES.DIANMITHIKAN) AS DIANAVG FROM OMADA6.JOKERWINCATEGORIES ";
            DianemithikanSQL  += "  inner join OMADA6.JOKERDRAWS on OMADA6.JOKERWINCATEGORIES.DRAWID = OMADA6.JOKERDRAWS.DRAWID  ";
            DianemithikanSQL  += "  WHERE OMADA6.JOKERDRAWS.DRAWTIME >= '"+fDate+"' AND OMADA6.JOKERDRAWS.DRAWTIME <= '"+tDate+"' ";
            DianemithikanSQL  += " GROUP BY OMADA6.JOKERWINCATEGORIES.TYPE ";
            PreparedStatement preparedStatement = connection.prepareStatement(DianemithikanSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnCat = rsEtos.getInt("DIANCAT");
               returnAvg = rsEtos.getDouble("DIANAVG");
               tmpMap.put(returnCat, returnAvg);
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των Διανεμηθέντων nnnnnnnnn" + ex.toString());
        }
        returnAvg = Math.round(returnAvg);
        return tmpMap;   
    }

    //Μέθοδος που επιστρέφει από την ΒΔ τα έτη που έχουμε αποθηκευμένες κληρώσεις
    public static ArrayList<Integer> showYears(){
        ArrayList<Integer> eth = new ArrayList<Integer>(); 
        Connection connection;
        connection = sqlController.connect();
        try{
            String ethSQL = "SELECT DISTINCT YEAR(DRAWTIME) AS ETOS FROM JOKERDRAWS";
            PreparedStatement preparedStatement = connection.prepareStatement(ethSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            
            while(rsEtos.next()){
               eth.add(rsEtos.getInt("ETOS"));
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των Ετών " + "JOKERDRAWS: " + ex.toString());
        }
        return eth;   
    }

    //Μέθοδος που επιστρέφει από την ΒΔ τις αποθηκευμένες κληρώσεις για συγκεκριμένο μήνα
    public static int showMonthKliroseis(int toEtos, int oMinas){
        int returnInt = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String kliroseisSQL = "SELECT COUNT(*) AS KLIROSEISCOUNT FROM JOKERDRAWS WHERE YEAR(DRAWTIME) = " + toEtos + " AND MONTH(DRAWTIME)="+oMinas;
            PreparedStatement preparedStatement = connection.prepareStatement(kliroseisSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnInt = rsEtos.getInt("KLIROSEISCOUNT");
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των Κληρώσεων " + ex.toString());
        }
        return returnInt;   
    }
    
    //Μέθοδος που επιστρέφει από την ΒΔ τα ποσά που διανεμήθηκαν για συγκεκριμένο μήνα ενός έτους
    public static double showMonthDianemithikan(int toEtos, int oMinas){
        double returnInt = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String DianemithikanSQL = "";
            DianemithikanSQL  += " SELECT SUM(JOKERWINCATEGORIES.DIANMITHIKAN) AS DIANEMSUM FROM JOKERWINCATEGORIES ";
            DianemithikanSQL  += " inner join JOKERDRAWS on JOKERWINCATEGORIES.DRAWID = JOKERDRAWS.DRAWID ";
            DianemithikanSQL  += " WHERE YEAR(JOKERDRAWS.DRAWTIME) = "+toEtos+" AND MONTH(JOKERDRAWS.DRAWTIME)="+oMinas;
            PreparedStatement preparedStatement = connection.prepareStatement(DianemithikanSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnInt = rsEtos.getDouble("DIANEMSUM");
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των Διανεμηθέντων " + ex.toString());
        }
        returnInt = Math.round(returnInt);
        return returnInt;   
    }
    
    //Μέθοδος που επιστρέφει από την ΒΔ τον αριθμό των Jackpots για συγκεκριμένο μήνα ενός έτους
    public static int showMonthJackpots(int toEtos, int oMinas){
        int returnInt = 0;
        Connection connection;
        connection = sqlController.connect();
        try{
            String JackpotsSQL = "";
            JackpotsSQL  += " SELECT COUNT(JOKERWINCATEGORIES.DRAWID) AS JACKPOTCOUNT FROM JOKERWINCATEGORIES ";
            JackpotsSQL  += " inner join JOKERDRAWS on JOKERWINCATEGORIES.DRAWID = JOKERDRAWS.DRAWID ";
            JackpotsSQL  += " WHERE JOKERWINCATEGORIES.JACKPOT > 1 AND YEAR(JOKERDRAWS.DRAWTIME) = "+toEtos+" AND MONTH(JOKERDRAWS.DRAWTIME)= "+oMinas+" ";
            PreparedStatement preparedStatement = connection.prepareStatement(JackpotsSQL);
            ResultSet rsEtos = preparedStatement.executeQuery();
            while(rsEtos.next()){
               returnInt = rsEtos.getInt("JACKPOTCOUNT");
            }
        } catch (SQLException ex) {
            //System.out.println(" Πρόβλημα στην εύρεση των JACKPOTS " + ex.toString());
        }
        return returnInt;
    }
   
    //Μέθοδος που διαγράφει από την ΒΔ μία κλήρωση
    public static String deleteKlirosi_fromDB(klirosi kl){
        String together = "";
        int count = 0;
        Connection connection;
        connection = sqlController.connect();

        //Διαγραφή κλήρωσης από τον πίνακα JOKERDRAWS
        try{
            int kl_draw = kl.getmydrawID();
            String deleteKlirosiSQL = "delete FROM JOKERDRAWS WHERE DRAWID=?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteKlirosiSQL);
            preparedStatement.setInt(1, kl_draw);
            count = preparedStatement.executeUpdate();
            if(count>0){
                together = "1";
            }
        } catch (SQLException ex) {
            //System.out.println(" Η κλήρωση απέτυχε να διαγραφεί από τον πίνακα " + "JOKERDRAWS: " + ex.toString());
        }
        
        //Διαγραφή κλήρωσης από τον πίνακα JOKERNUMSNORMAL
        try{
            int kl_draw = kl.getmydrawID();
            String deleteWinNumberSQL = "delete FROM JOKERNUMSNORMAL WHERE DRAWID=?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteWinNumberSQL);
            preparedStatement.setInt(1, kl_draw);
            count = preparedStatement.executeUpdate();
            if(count>0){
                together += "1";
            }
        } catch (SQLException ex) {
            //System.out.println(" Η κλήρωση απέτυχε να διαγραφεί από τον πίνακα " + "JOKERNUMSNORMAL: " + ex.toString());
        }
        
        //Διαγραφή κλήρωσης από τον πίνακα JOKERNUMSJOKER
        try{
            int kl_draw = kl.getmydrawID();
            String deleteJokerSQL = "delete FROM JOKERNUMSJOKER WHERE DRAWID=?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteJokerSQL);
            preparedStatement.setInt(1, kl_draw);
            count = preparedStatement.executeUpdate();
            if(count>0){
                together += "1";
            }
        } catch (SQLException ex) {
            //System.out.println(" Η κλήρωση απέτυχε να διαγραφεί από τον πίνακα " + "JOKERNUMSJOKER: " + ex.toString());
        }
        
        //Διαγραφή κλήρωσης από τον πίνακα JOKERWINCATEGORIES
        try{
            int kl_draw = kl.getmydrawID();
            String deleteCategoriesSQL = "delete FROM JOKERWINCATEGORIES WHERE DRAWID=?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteCategoriesSQL);
            preparedStatement.setInt(1, kl_draw);
            count = preparedStatement.executeUpdate();
            if(count>0){
                together += "1";
            }
        } catch (SQLException ex) {
            //System.out.println(" Η κλήρωση απέτυχε να διαγραφεί από τον πίνακα " + "JOKERWINCATEGORIES: " + ex.toString());
        }
        return together; 
    }
    
    //Μέθοδος που αποθηκεύει στην ΒΔ μία κλήρωση
    public static String saveKlirosi_toDB(klirosi kl){
        
        String returnStr = "";
        int kl_draw = kl.getmydrawID();
        int kl_game = 5104;
        Date kl_date = kl.getmydrawDate();
        java.sql.Date kl_sqlDate = new java.sql.Date(kl_date.getTime());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
             Connection connection;
             connection = sqlController.connect();
             
             //Εισαγωγή Κλήρωσης
             String insertKlirosiSQL = "INSERT INTO JOKERDRAWS (DRAWID,GAMEID,DRAWTIME) VALUES(?,?,?)";
             PreparedStatement preparedStatement = connection.prepareStatement(insertKlirosiSQL);
             preparedStatement.setInt(1, kl_draw);
             preparedStatement.setInt(2, kl_game);
             preparedStatement.setDate(3, new java.sql.Date(kl_date.getTime()));
             int count = preparedStatement.executeUpdate();
             if(count>0){
                //Εισαγωγή Νικητήριων Αριθμών
                for (int i = 0; i < kl.myWinningNumbers.size(); i++){
                    int theNum = kl.myWinningNumbers.get(i);
                    String insertWinNumberSQL = "INSERT INTO JOKERNUMSNORMAL (DRAWID,NUMBER) VALUES(?,?)";
                    PreparedStatement preparedStWinNum = connection.prepareStatement(insertWinNumberSQL);
                    preparedStWinNum.setInt(1, kl_draw);
                    preparedStWinNum.setInt(2, theNum);
                    count = preparedStWinNum.executeUpdate();
                    preparedStWinNum.close();
                }

                //Εισαγωγή Αριθμού Joker
                    int theJoker = kl.getmyJoker();
                    String insertJokerSQL = "INSERT INTO JOKERNUMSJOKER (DRAWID,JOKER) VALUES(?,?)";
                    PreparedStatement preparedStJokNum = connection.prepareStatement(insertJokerSQL);
                    preparedStJokNum.setInt(1, kl_draw);
                    preparedStJokNum.setInt(2, theJoker);
                    count = preparedStJokNum.executeUpdate();
                    
                //Εισαγωγή Κατηγοριών Κερδών
                    for (Map.Entry<Integer, katigoriaKerdous> klCat : kl.katigories.entrySet()){
                        katigoriaKerdous dKatigoriaKerdous = klCat.getValue();
                        int theCatType = dKatigoriaKerdous.getcatType();
                        double theCatKerdoi = dKatigoriaKerdous.getcatKerdoi();
                        long theCatNikites = dKatigoriaKerdous.getcatNikites();
                        double theCatDian = dKatigoriaKerdous.getcatDianmithikan();
                        double theCatJackpot = dKatigoriaKerdous.getcatJackpot();
                        String insertCategorieSQL = "INSERT INTO JOKERWINCATEGORIES (DRAWID,GAMEID,TYPE,KERDI,NIKITES,DIANMITHIKAN,JACKPOT) VALUES(?,?,?,?,?,?,?)";
                        PreparedStatement preparedStCategorie = connection.prepareStatement(insertCategorieSQL);
                        preparedStCategorie.setInt(1, kl_draw);
                        preparedStCategorie.setInt(2, kl_game);
                        preparedStCategorie.setInt(3, theCatType);
                        preparedStCategorie.setDouble(4, theCatKerdoi);
                        preparedStCategorie.setLong(5, theCatNikites);
                        preparedStCategorie.setDouble(6, theCatDian);
                        preparedStCategorie.setDouble(7, theCatJackpot);
                        count = preparedStCategorie.executeUpdate();
                        preparedStCategorie.close();
                    }
             }
             preparedStatement.close();
             connection.close();
             String x = "Y";
             return x;
        } catch (SQLException ex) {
            //System.out.println(" SQL Error: " + ex.toString());
        }
        return returnStr;
    }

    
}
