
package pkg2022_plh24_omada_6;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 *Gavouchidis Stefanos
 *Tsigkris Polydoros
 *Filippidis Savvas
 *
 */

public class createTables {
    
    //Μέθοδος που εκτελείται κατά την εκκίνηση του προγράμματος έτσι ώστε να δημιουργηθούν οι πίνακες της ΒΔ που δεν υπάρχουν
    public static boolean checkTableExistsSQL(Connection connection, String tableName){
        boolean retBool = false;
        try {
            connection = sqlController.connect();
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT count(*) AS THECOUNT "
              + " FROM SYS.SYSTABLES "
              + " WHERE TABLENAME=?"
              + "");
            preparedStatement.setString(1, tableName.toUpperCase());
            ResultSet resultSet = preparedStatement.executeQuery();
                if(resultSet.next()){
                     if(resultSet.getInt("THECOUNT") == 1){
                        retBool = true;
                     }
                }else{
                     retBool = false;
                }
                 preparedStatement.close();
                 connection.close();
        } catch (SQLException ex) {
                //System.out.println("SQL Error = " + ex.toString());
        }  
        return retBool;
    }
    
    ////Μέθοδος που δημιουργεί τους πίνακες της ΒΔ που δεν υπάρχουν
    public static void createTableAndData(){
        try {
            Connection connection = sqlController.connect();
            
            // Δημιουργία Πίνακα Κληρώσεεων
            if(checkTableExistsSQL(connection, "JOKERDRAWS")==false){
                Statement stmDraws = connection.createStatement();
                String createDrawsSql = "CREATE TABLE JokerDraws"
                   + " (drawId INTEGER NOT NULL PRIMARY KEY,"
                   + " gameId INTEGER NOT NULL DEFAULT 5104,"     
                   + " drawTime DATE NOT NULL)"; 
                stmDraws.executeUpdate(createDrawsSql); 
            }
             
            // Δημιουργία Πίνακα Κατηγορία Κανονικών αριθμών
            if(checkTableExistsSQL(connection, "JokerNumsNormal")==false){
                Statement stmNumbersNormal = connection.createStatement();
                String createNumbersNormalSql = "CREATE TABLE JokerNumsNormal"
                   + " (aa INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"     
                   + " drawId INTEGER NOT NULL,"
                   + " number INTEGER NOT NULL)"; 
                stmNumbersNormal.executeUpdate(createNumbersNormalSql); 
            }
             
            // Δημιουργία Πίνακα Κατηγορία Κανονικών αριθμών
            if(checkTableExistsSQL(connection, "JokerNumsJoker")==false){
                Statement stmNumbersJoker = connection.createStatement();
                String createNumbersJokerSql = "CREATE TABLE JokerNumsJoker"
                   + " (aa INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"     
                   + " drawId INTEGER NOT NULL,"
                   + " joker INTEGER NOT NULL)"; 
                stmNumbersJoker.executeUpdate(createNumbersJokerSql); 
            }

            // Δημιουργία Πίνακα Κατηγοριών Κερδών
            Statement statementCategories = connection.createStatement();
            String createTableCat = "CREATE TABLE JokerWinCategories"
               + " (aa INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"     
               + " drawId INTEGER NOT NULL,"
               + " gameId INTEGER NOT NULL DEFAULT 5104,"     
               + " type INTEGER NOT NULL,"
               + " kerdi DOUBLE NOT NULL,"
               + " nikites DOUBLE NOT NULL," 
               + " dianmithikan DOUBLE NOT NULL," 
               + " Jackpot DOUBLE NOT NULL)"; 
            statementCategories.executeUpdate(createTableCat); 
            statementCategories.close();

            connection.close();
        } catch (SQLException ex) {
            //System.out.println("sql catch Exception = " + ex.getMessage());
        }
    }
}
